# DEC RSTS/E BASIC-PLUS-2 Modern Environment
**Release Version**: 10.1-L
**Target Platform**: Linux-x86_64
**Build Date**: 2026-10-15 16:30:30 UTC

## Quick Installation
To install DEC BASIC-PLUS-2:
```bash
./install.sh
```
For custom prefix:
```bash
./install.sh --prefix=/opt/dec-basic2
```

## Included Subsystems
- `bin/basicc`: Pure DEC BASIC-PLUS-2 Compiler
- `bin/basiclink`: Pure DEC BASIC-PLUS-2 Linker and Overlay Manager
- `bin/rsts_vm`: High-performance C Bytecode Runtime
- `bin/dcl`: DIGITAL Command Language (DCL) Processor & PBS Shell
- `bin/edt`: DEC EDT Editor V3.0 (Line Mode & VT100 Screen Mode)
- `bin/dec-printq`: Print/Batch Services Symbiont Daemon

See `docs/USER_GUIDE.md` and `docs/ARCHITECTURE.md` for complete instructions.
